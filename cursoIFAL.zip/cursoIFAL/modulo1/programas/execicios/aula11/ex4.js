<script>
var x = 0

while(x<=80){
	x = Math.floor(Math.random()*101)
    document.write(x+"<br>")
}
</script>