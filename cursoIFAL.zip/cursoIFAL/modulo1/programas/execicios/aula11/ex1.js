<script>
let i = 1 
let soma = 0 

while(i<=100){
	if(i%2==0){
    
	soma = soma + i
    document.write(i+"<br>")
    
	}
    i++
}
document.write("soma: "+ soma)
</script>

