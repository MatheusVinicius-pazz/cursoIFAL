<script>
let numAl


while(numAl != 6 && numAl != 46){
numAl = Math.floor(Math.random()*71)
document.write(`${numAl}<br>`)
}

</script>
