
let n = Number(prompt("Digite um número:"))
let soma = 0

for(let i = 0; i<=n; i++){

    
    soma = soma + i
         document.write(i+'<br>')
  
   
}
document.write(`soma: ${soma}`)
