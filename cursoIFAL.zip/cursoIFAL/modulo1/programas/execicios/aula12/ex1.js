for(let i = 100; i<=120; i++){
    document.write(i+'<br>')
}