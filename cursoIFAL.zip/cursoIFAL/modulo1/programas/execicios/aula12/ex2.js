for(let i = 50; i>=7; i--){

    if(i%2==1){
         document.write(i+'<br>')
    }
   
}