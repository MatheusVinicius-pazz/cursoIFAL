let altura 
let soma = 0
let numeroDejogadores = Number(prompt('Digite o número de jogadores:'))

for(let i = 1; i<=numeroDejogadores; i++){
    altura = Number(prompt('Digite a altura dod jogadores:'))
    soma = altura + 
}