let clienteA = {
    nome: 'João',
    endereco: 'rua Tal, 10 - Tabuleiro - Maceió -  AL - CEP: 57000-000'
}

let clienteB = {
    nome: 'Cleiton',
    rua:'X',
    numero: '15',
    bairro: 'Mata do Rolo',
    cidade: 'Rio Largo'


}

clienteC = {
    nome: 'Rasta',

    endereco: {
        rua: 'Da pedra',
        numero: '20',
        bairro: 'centro',
        cidade: 'Cajueiro'
    }
}




console.log("Cliente A: ", clienteA.endereco);
console.log("Cliente B: ", clienteB.cidade);
console.log("Cliente C: ", clienteC.endereco.cidade);
console.log('------------------------------------------------------')
//-----------------------------------------------------------------
// Função para fazer uma requisição HTTP GET
// o código abaixo consulta as informações usando a api de CEP dos correios.
/*
function getCEP(cep) {
    fetch(`https://viacep.com.br/ws/${cep}/json/`)
      .then(response => response.json())
      .then(data => {
        // Verifica se o CEP foi encontrado
        if (!data.erro) {
          // Exibe as informações do endereço
          console.log("CEP:", data.cep);
          console.log("Logradouro:", data.logradouro);
          console.log("Complemento:", data.complemento);
          console.log("Bairro:", data.bairro);
          console.log("Cidade:", data.localidade);
          console.log("Estado:", data.uf);
        } else {
          console.log("CEP não encontrado.");
        }
      })
      .catch(error => {
        console.error('Ocorreu um erro:', error);
      });
  }
  
  // Exemplo de uso da função
  getCEP('57990000'); // Insira o CEP desejado aqui
  */

  alunoA = {
    nome: 'José',
    disciplinas: ['POO', 'PWEB']
  };
  alunoB = {
    nome: 'Maria',
    historico: {
        poo: 10,
        pweb: 9,
        bd: 9.5,
        aps: 10
    }
  };



alunoA.disciplinas.push('BD', 'APS', 'SO', 'REDES');

console.log('Nome: ',alunoA.nome);
console.log('Disciplinas: ')
  for(i=0; i<alunoA.disciplinas.length; i++ ){
    console.log(alunoA.disciplinas[i]);
  };
  
  console.log('Nome: ',alunoB.nome);
  console.log(alunoB.historico.bd)
  console.log('------------------------------------------------------')

  turmaX = {
    codigo: 'info034',
    disciplina: 'POO',
    alunos: ['Edilene', ' Sthefany', ' Pedro', ' Daniel', ' Nathalya', ' Matheus', ' Airton']

  };

  console.log(`TurmaX \n Código: ${turmaX.codigo}\n Displina: ${turmaX.disciplina} \n Alunos: ${turmaX.alunos}` );
  console.log('------------------------------------------------------')

  turmaY = {
    codigo: 'info034',
    disciplina: 'POO',
    alunos: [
    {nome: 'Daniel', cpf: '000.000.000-00'}, 
    {nome: 'Pedro', cpf: '111.111.111-11'}, 
    {nome: 'Airton', cpf: '222.222.222-22'} ]

  };

  console.log(`TurmaY \n Código: ${turmaY.codigo}\n Displina: ${turmaY.disciplina} \n `);

  console.log('Alunos: ')
  for(i=0; i<turmaY.alunos.length;i++){
    console.log(` Nome: ${turmaY.alunos[i].nome} - CPF:${turmaY.alunos[i].cpf}`);
  };

